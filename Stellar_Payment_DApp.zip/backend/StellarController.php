
<?php

use GuzzleHttp\Client;

class StellarController extends Controller
{
    public function sendPayment(Request $request)
    {
        $client = new Client();
        $url = 'https://horizon-testnet.stellar.org/transactions';

        $response = $client->post($url, [
            'json' => [
                'source' => $request->input('source'),
                'destination' => $request->input('destination'),
                'amount' => $request->input('amount'),
                'asset' => 'native',
            ]
        ]);

        return response()->json(json_decode($response->getBody(), true));
    }
}
