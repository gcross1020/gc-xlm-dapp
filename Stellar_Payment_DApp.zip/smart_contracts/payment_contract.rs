
#![no_std]
use soroban_sdk::{contract, contractimpl, Address, Env, Symbol, Vec};

#[contract]
pub struct PaymentContract;

#[contractimpl]
impl PaymentContract {
    // Function to transfer tokens between two accounts
    pub fn transfer(env: Env, from: Address, to: Address, amount: i128) {
        let from_balance = env.accounts().get_balance(from);
        assert!(from_balance >= amount, "Insufficient funds");
        env.accounts().set_balance(from, from_balance - amount);
        env.accounts().set_balance(to, env.accounts().get_balance(to) + amount);
    }

    // Function to mint new tokens to an account
    pub fn mint(env: Env, to: Address, amount: i128) {
        env.accounts().set_balance(to, env.accounts().get_balance(to) + amount);
    }

    // Function to get the balance of a given account
    pub fn get_balance(env: Env, account: Address) -> i128 {
        env.accounts().get_balance(account)
    }
}
