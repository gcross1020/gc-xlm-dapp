
import { StellarWalletSdk } from 'stellar-wallet-sdk';
import { Server, TransactionBuilder, BASE_FEE, Networks, Keypair } from 'stellar-sdk';

const server = new Server('https://horizon-testnet.stellar.org');
const wallet = new StellarWalletSdk();

async function connectWallet() {
    const account = await wallet.connect();
    console.log('Connected account:', account);
}

async function sendPayment(amount, destinationPublicKey) {
    const sourceKeypair = Keypair.fromSecret('YOUR_SECRET_KEY');
    
    const sourceAccount = await server.loadAccount(sourceKeypair.publicKey());
    
    const transaction = new TransactionBuilder(sourceAccount, {
        fee: BASE_FEE,
        networkPassphrase: Networks.TESTNET
    })
    .addOperation(Operation.payment({
        destination: destinationPublicKey,
        asset: Asset.native(),
        amount: amount.toString(),
    }))
    .setTimeout(30)
    .build();
    
    transaction.sign(sourceKeypair);
    try {
        const result = await server.submitTransaction(transaction);
        console.log('Payment successful!', result);
    } catch (e) {
        console.error('Payment failed!', e);
    }
}
